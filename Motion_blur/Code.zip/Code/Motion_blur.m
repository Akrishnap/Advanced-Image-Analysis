clear all;
close all;
clc;


%% Adding Blur to the Image

I = im2double(imread('lena.jpg'));
figure; imshow(I); title('Original Image');%displays original image
LEN = 31; %the length of the motion blur
THETA = 11; %the angle of the motion blur
PSF = fspecial('motion',LEN,THETA); % create PSF
Blurred = imfilter(I,PSF,'conv','circular'); %convolves the input image with the PSF
Blurred_noise = imnoise(Blurred, 'gaussian'); % Add noise
figure; imshow(Blurred); title('Blurred Image'); %displays blurred image
figure; imshow(Blurred_noise); title('Blurred and Noisy Image'); %displays blurred image
figure; imshow(PSF, [], 'InitialMagnification', 'fit');title('PSF Kernel'); 

%%  DeBlurring using Inverse, Wiener, Regularized and Lucy-Richardson algorithms

% Blurred = edgetaper(Blurred,PSF); % To remove the ringing effect

% Weiner Method%
wnr = deconvwnr(Blurred,PSF); % Weiner filtering function
figure;imshow(wnr); %displays deblurred image
title('Wiener Filter');

% Regularized Method%
reg = deconvreg(Blurred, PSF) ; % regularized filter
figure; imshow(reg) ; %displays deblurred image
title('Regularized Filter') ;

% Lucy-Richardson method%
lucy = deconvlucy(Blurred,PSF); %Lucy-Richardson filtering function
figure;imshow(lucy); %displays deblurred image
title('Lucy-Richardson Method')

% To Deblur Blur and noisy image

% PSF = fspecial('Motion',25,10); % To guess the PSF
% INITPSF = ones(size(PSF)); %creates a matrix of the same size 

PSF=ones(15:15); % To guess the PSF

[J P]= deconvblind(Blurred_noise,PSF); % Blind Convolution 
figure; imshow(J,[]); title('Restored Image');

