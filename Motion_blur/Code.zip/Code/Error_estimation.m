I = im2double(imread('Lena256.bmp'));
figure(5),imshow(I);

%MOTION BLUR simulation
PSF = fspecial('motion',15 ,10);
blurred = imfilter(I, PSF, 'conv', 'circular');
figure(1), imshow(blurred)


Irec1 = deconvwnr(blurred, PSF, 0);%reconstructed image
figure(2), imshow(Irec1)
% 
%error betwwen reconst and original image
diff = I - Irec1;
mserr_nonoise = sum(sum(diff.*diff))


%ADD NOISE
noise_var = 0.001;
blurred = imnoise(blurred, 'gaussian',0, noise_var);
figure(3), imshow(blurred)

estimated_nsr = noise_var / var(I(:));%estimated noise ratio
Irec2 = deconvwnr(blurred, PSF, estimated_nsr);%reconstructed image 
figure(4), imshow(Irec2)

%error betwwen reconst and original image
diff = I - Irec2;
mserr_noise = sum(sum(diff.*diff))

