clear all;
clc;

I=im2double(imread('Lena256.bmp'));% original image
n=1; % Threshold
PSF = fspecial('motion', 31,10);% create PSF
blur=imfilter(I,PSF,'conv','circular'); %convolves the input image with the PSF
figure(1),imshow(blur); %displays blurred image

PSF = fft2(PSF,256,256);% Fourier Transform of PSF
I=fft2(I);% Fourier Transform of Original Image
Ib=(I.*PSF);%convolves the input image with the PSF
figure(2);imshow(Ib);%displays blurred image
Ib_ifft = ifft2(Ib);% Inverse Fourier Transform of Blur Image 
IB = Ib_ifft+10 * randn(256,256);% Noise added
imagesc(abs(Ib_ifft));
Gg=fft2(IB); % Fourier Transform of blurred+noise image
figure(3),imshow(Gg,[]);

imagesc(abs(ifft2(Gg)));%performing inverse fourier transform
PSF(abs(PSF)>n) = n;% taking the threshold and comparing
B=1./PSF;%Inverse filter
Im=Ib./PSF;%Restoration filter
im=abs(ifft2(Im));%inverse fourier transform
imagesc(im);
title('Inverse Filtering Restored Image');
