function [im]=Inv_wavelet_transform(wavelet,nlevel,h)

im = wavelet;
g = h.*power(-1*ones(1,length(h)),(0:length(h)-1));
h = h(end:-1:1);
g = g(end:-1:1);
[r1,c1] = size(im);

j = nlevel:-1:1 ;
r2 = r1/2^(j-1);
c2 = c1/2^(j-1);
d = im(1:r2,1:c2);

%Inverse Wavelet Transform

% Up Sampling
[r2 c2]=size(d);
L = zeros(size(d),'double');
H = zeros(size(d),'double');
L(:,1:2:end) = d(:,1:c2/2,:);
L(:,2:2:end) = d(:,1:c2/2,:);
H(:,1:2:end) = d(:,c2/2+1:end);
H(:,2:2:end) = d(:,c2/2+1:end);

%Low Pass Filtering
L = imfilter(L,h,'circular','conv');

%High Pass Filtering
H = imfilter(H,g,'circular','conv');

LH = L+H;

%Up Sampling
[r3 c3]=size(LH); 
C = zeros(size(LH),'double');
D = zeros(size(LH),'double');
C(1:2:end,:) =LH(1:r3/2,:);
D(1:2:end,:) = LH(r3/2+1:end,:);
C(2:2:end,:) = LH(1:r3/2,:);
D(2:2:end,:) = LH(r3/2+1:end,:);
    
%Low Pass Filtering
L1 = imfilter(C,h,'circular','conv');

%High Pass Filtering
H1 = imfilter(D,g,'circular','conv');

LH1 = L1+H1;

[r3 c3] = size(LH1);
im(1:r3,1:c3) = LH1;
 
[r4 c4] = size(LH1);
im(1:r4,1:c4) = LH1;

end
