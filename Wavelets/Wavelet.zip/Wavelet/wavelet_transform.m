
function [wavelet] = wavelet_transform(I,J,h)

wavelet = zeros(size(I),'double');
g = h.*power(-1*ones(1,length(h)),(0:length(h)-1));

J = 1 ; % J-level
for i=1:J
    img=I(1:i:end,1:i:end);

    %Low Pass Filtering
     L = imfilter(img,h','same','replicate','conv');
    %High Pass Filtering 
     H = imfilter(img,g','same','replicate','conv');

    %Downsampling
     x = L(:,1:2:end);
     y = H(:,1:2:end);
     z = [x y];
    
    %Low Pass Filtering
     L1 = imfilter(z,h,'circular','conv');
    %High Pass Filtering 
     H1 = imfilter(z,g,'circular','conv');

    %Downsampling
     a=L1(1:2:end,:);
     b=H1(1:2:end,:);
     d= [a;b];
     [r c]=size(d);
     wavelet(1:r,1:c) = d;

end
end


