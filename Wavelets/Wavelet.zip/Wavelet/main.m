
clc;
close all;
clear all;

I = imread('Lena256.bmp');
figure(1),imshow(I);
title('Original Image');


h = [0.48296 0.83652 0.22414 -0.12941];
g = h.*power(-1*ones(1,length(h)),(0:length(h)-1));
J = 1;
w_t = wavelet_transform(I,J,h);

figure(2),imshow(w_t,[]);
title('Wavelet Transform');

i_w_t  = Inv_wavelet_transform(w_t,J,h);
figure(3),imshow(i_w_t,[]);
title('Inverse Wavelet Transform');

I1 = double(I);
sb = I1 + randn(256,256)*10;
wt = wavelet_transform(sb,J,h);

%Estimation of the noise level
hf = [wt(129:256,1:128) wt(129:256,129:256) wt(1:128,129:256)];
sigma = median(abs(hf(:)))/0.6745 ;
threshold = 3*sigma;

% Hard Thresholding
hard_th = wt.*((abs(wt)>threshold));
hard = Inv_wavelet_transform(hard_th,J,h);
figure(4),imshow(hard,[]);
title('Hard Thresholding');

% Soft Thresholding
soft_th = (sign(wt).*(abs(wt)-threshold)).*((abs(wt)>threshold));
soft = Inv_wavelet_transform(soft_th,J,h);
figure(5),imshow(soft,[]);
title('Soft Thresholding');



